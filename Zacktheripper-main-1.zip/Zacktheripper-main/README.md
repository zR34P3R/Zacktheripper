# Zacktheripper

More commands coming soon!

![20210208_133830](https://user-images.githubusercontent.com/78533079/107517549-8f759600-6bb6-11eb-9861-11db8704a81d.png)

Linux installation:bash linux-install
Termux installation:bash termux-install



And thanks for installing! :)
